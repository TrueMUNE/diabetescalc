# train_model.py
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import joblib
from sklearn.preprocessing import StandardScaler

# Load your dataset (replace 'diabetes_dataset.csv' with your actual dataset)
dataset = pd.read_csv('C:/Users/muham/Documents/diabetes_calculator/diabetes_dataset.csv')

# Extract features and labels
X = dataset.drop('Outcome', axis=1)
y = dataset['Outcome']

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Scale the features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train a logistic regression model
model = LogisticRegression(max_iter=1000)
model.fit(X_train_scaled, y_train)

# Save the trained model
joblib.dump(model, 'model.pkl')

# ...

# Train a logistic regression model
model = LogisticRegression(max_iter=1000)
model.fit(X_train_scaled, y_train)

# Evaluate the model on the training set
train_accuracy = model.score(X_train_scaled, y_train)
print(f'Training Accuracy: {train_accuracy}')

# Evaluate the model on the testing set
test_accuracy = model.score(X_test_scaled, y_test)
print(f'Testing Accuracy: {test_accuracy}')

# Save the trained model
joblib.dump(model, 'model.pkl')

# train_model.py
import os

# ... (rest of your code)

# Save the trained model
model_filename = 'model.pkl'
model_path = os.path.abspath(model_filename)
joblib.dump(model, model_filename)

print(f"Model saved at: {model_path}")

