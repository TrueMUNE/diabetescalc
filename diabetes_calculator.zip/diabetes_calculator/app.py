# app.py
from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        # Extracting features from the form
        features = [float(x) for x in request.form.values()]
        input_data = np.array(features).reshape(1, -1)

        # Wrap the model loading in app context
        with app.app_context():
            # Load the pre-trained model
            model = joblib.load('model.pkl')

        # Make prediction
        prediction = model.predict(input_data)[0]

        # Map numerical prediction to "Yes" or "No"
        prediction_label = "Yes" if prediction == 1 else "No"

        return render_template('result.html', prediction=prediction_label)

if __name__ == '__main__':
    app.run(debug=True)










from flask import Flask, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from forms import LoginForm
from models import User
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'

# Specify Absolute Path for the Database
import os
db_path = os.path.join(os.getcwd(), 'db', 'users.db')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + db_path
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Load user
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
@login_required
def home():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()

    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()

        if user and user.check_password(form.password.data):
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid username or password', 'danger')

    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=False, port=5001)
    from werkzeug.serving import run_simple
    run_simple('localhost', 5001, app, use_reloader=True, use_debugger=True)






